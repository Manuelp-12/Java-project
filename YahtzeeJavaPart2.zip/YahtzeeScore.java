package yahtzeescore;
import java.util.ArrayList;
import java.util.Arrays;
/* Starter file for JHU CTY AP CS Course Final Project 
 * Initial code for YahtzeeScore with stub implementations
 */

public class YahtzeeScore {
	/* Constructor, parameter dice contains values of dice to be scored 
	 * */
	private int[] dice;
	
	public YahtzeeScore(int[] givendice) {
		dice = givendice;
	}
	public int[] scoreDice() {
		return dice;
	}
	
	/* For a given hand calculate the lower score; if value is 1 score ones, etc. */
    public int getUpperScore(int value) {
    	int count = 0;
    	
        for (int i = 0; i < dice.length; i++) {
        	if (dice[i] == value)
        		count++;
        }
        
        return count * value;
    }
    public int scoreThreeOfAKind() {
    	int count = 0;
    	
    	for (int i = 0; i < dice.length; i++) {
    		for (int j = 0; j < dice.length; j++) {
    			if (dice[i] == dice[j]) {
    				count++;
    			}
    		}
    		if (count >= 3) {
    			int total = 0;
    			for (int k = 0; k < dice.length; k++) {
    				total += dice[k];
    			}
    			return total;
    		}
    		else {
    			count = 0;
    		}
    	}
    	return 0;
    }
    public int scoreFourOfAKind() {
    	int count = 0;
    	
    	for (int i = 0; i < dice.length; i++) {
    		for (int j = 0; j < dice.length; j++) {
    			if (dice[i] == dice[j]) {
    				count++;
    			}
    		}
    		if (count >= 4) {
    			int total = 0;
    			for (int k = 0; k < dice.length; k++) {
    				total += dice[k];
    			}
    			return total;
    		}
    		else {
    			count = 0;
    		}
    	}
    	return 0;
    }

    public int scoreFullHouse() {
    	int count = 0;
    	int count2 = 0;
    	
    	for (int i = 0; i < dice.length; i++) {
    		for (int j = 0; j < dice.length; j++) {
    			if (dice[i] == dice[j]) {
    				count++;
    			}
    		}
    		if (count == 3) {
    			ArrayList<Integer> dice2 = new ArrayList<Integer>();
    			
    			for (int k = 0; k < dice.length; k++) {
    				if (dice[k] != dice[i]) {
    					dice2.add(dice[k]);
    				}
    			}
    			for (int l = 0; l < dice2.size(); l++) {
    				if (dice2.get(0) == dice2.get(l)) {
    					count2++;
    				}
    			}
    			if (count2 >= 2) {
    				return 25;
    			}
    			else {
    				return 0;
    			}
    		}
    		else {
    			count = 0;
    		}
    	}
    	return 0;
    }

    public int scoreSmallStraight() {
    	int count = 0;
    	int[] dice2 = removeduplicates(dice);
    	Arrays.sort(dice2);
    	
    	for (int i = 1; i < dice2.length; i++) {
    		if ((dice2[i - 1] + 1) == dice2[i]) {
    			count++;
    		}
    		else {
    			count = 0;
    		}
    	}
    	if (count >= 3) {
    		return 30;
    	}
    	else {
    		return 0;
    	}
    }

    public int scoreLargeStraight() {
    	int[] dice2 = dice;
    	Arrays.sort(dice2);
    	
    	int[] largechecker = {1, 2, 3, 4, 5};
    	int[] largechecker2 = {2, 3, 4, 5, 6};
    	
    	if (Arrays.equals(dice2, largechecker)) {
    		return 40;
    	}
    	else if (Arrays.equals(dice2, largechecker2)) {
    		return 40;
    	}
    	else {
    		return 0;
    	}
    }


    public int scoreChance() {
    	int total = 0;
    	
    	for (int i = 0; i < dice.length; i++) {
    		total += dice[i];
    	}
    	return total;
    }


    public int scoreYahtzee() {
    	int count = 0;
    	
    	for (int i = 0; i < dice.length; i++) {
    		for (int j = 0; j < dice.length; j++) {
    			if (dice[i] == dice[j]) {
    				count++;
    			}
    		}
    		if (count >= 5) {
    			return 50;
    		}
    		else {
    			count = 0;
    		}
    	}
    	return 0;
    }

    public int scoreBonusYahtzee() {
    	int count = 0;
    	
    	for (int i = 0; i < dice.length; i++) {
    		for (int j = 0; j < dice.length; j++) {
    			if (dice[i] == dice[j]) {
    				count++;
    			}
    		}
    		if (count >= 5) {
    			return 100;
    		}
    		else {
    			count = 0;
    		}
    	}
    	return 0;
    }
    public int[] removeduplicates(int[] data){
        ArrayList<Integer> uniqueElements = new ArrayList<>();
        for(int value : data){
            if(!uniqueElements.contains(value)){
                uniqueElements.add(value);
            }
        }
        int[] result = new int[uniqueElements.size()];
        int i = 0;
        for(int val : uniqueElements){
            result[i++] = val;
        }
        return result;
    }
}
