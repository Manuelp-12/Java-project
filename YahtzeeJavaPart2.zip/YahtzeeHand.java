package yahtzeehand;
import die.Die;

/* Starter file for JHU CTY AP CS Course Final Project 
 * Initial code for YahtzeeHand with stub implementations
 */

public class YahtzeeHand {
	private Die[] hand = new Die[5];
	private Die die1 = new Die();
	private Die die2 = new Die();
	private Die die3 = new Die();
	private Die die4 = new Die();
	private Die die5 = new Die();
	
	public YahtzeeHand() {
		die1.roll();
		die2.roll();
		die3.roll();
		die4.roll();
		die5.roll();
		
		hand[0] = die1;
		hand[1] = die2;
		hand[2] = die3;
		hand[3] = die4;
		hand[4] = die5;
	}
	/*
     * Returns array of integers with current values of the dice
     */
    public int[] getDice() {
    	int[] values = new int[5];
    	
    	for(int i = 0; i < 5; i++) {
    		values[i] = hand[i].getValue();
    	}
    	
    	return values;
    }
    
    /* Roll all dice */
    public void rollAll() {
    	for (int i = 0; i < 5; i++) {
    		hand[i].roll();
    	}
    }

    /* Rolls specific dice */
    public void roll(int number) {
    	hand[number - 1].roll();
    }
    
    /* Allow user to change dice by rolling two
     * more times, user can choose which dice to keep
     */
    public void changeHand() {
    	rollAll();
    	rollAll();
    }
    
    /* Returns value of specified dice */
    public int get(int number) {
        return hand[number - 1].getValue();
    }

    /* Return string representing current state of the dice in 
     * the following format (or similar):
     * +------+---+---+---+---+---+
     * | Dice | 1 | 2 | 3 | 4 | 5 |
     * +------+---+---+---+---+---+
     * | Face | 4 | 2 | 4 | 6 | 1 |
     * +------+---+---+---+---+---+
     * 
     */
    public String showDice() {
    	String table = "";
    	table += "+------+---+---+---+---+---+\n";
    	table += "| Dice | 1 | 2 | 3 | 4 | 5 |\n";
    	table += "+------+---+---+---+---+---+\n";
    	table += "| Face | " + get(1) + " | " + get(2) + " | " + get(3) + " | " + get(4) + " | " + get(5) + " | \n";
    	table += "+------+---+---+---+---+---+\n";
    	return table;
    }
}
