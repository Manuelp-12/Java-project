package main;
import yahtzeehand.YahtzeeHand;
import yahtzeescore.YahtzeeScore;
import yahtzeescorecard.YahtzeeScoreCard;
import java.util.Arrays;
import java.util.Scanner;
import java.util.ArrayList;
import yahtzeeguiscorecard.YahtzeeGuiScoreCard;

public class Main {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList<Integer> keptdice = new ArrayList<Integer>();
		ArrayList<Integer> rolleddice = new ArrayList<Integer>();
		YahtzeeHand yahtzee = new YahtzeeHand();
		int ones = 0;
		int twos = 0;
		int threes = 0;
		int fours = 0;
		int fives = 0;
		int sixes = 0;
		int threeofakind = 0;
		int fourofakind = 0;
		int fullhouse = 0;
		int smallstraight = 0;
		int largestraight = 0;
		int chance = 0;
		int yahtzee2 = 0;
		
		boolean ones2 = false;
		boolean twos2 = false;
		boolean threes2 = false;
		boolean fours2 = false;
		boolean fives2 = false;
		boolean sixes2 = false;
		boolean threeofakind2 = false;
		boolean fourofakind2 = false;
		boolean fullhouse2 = false;
		boolean smallstraight2 = false;
		boolean largestraight2 = false;
		boolean chance2 = false;
		boolean yahtzee3 = false;
		
		//YahtzeeGuiScoreCard card = new YahtzeeGuiScoreCard();
		
		for (int z = 0; z < 13; z++) {
			yahtzee.rollAll();
			System.out.println(yahtzee.showDice());
			
			for (int j = 0; j < 2; j++) {
				System.out.print("Enter which dice number(s) you would like to keep (#1-5; if none, type none, if all, type all): ");
				String input = s.nextLine();
			
				if (input.equals("all")) {
					break;
				}
				else if (input.equals("none")) {
					yahtzee.rollAll();
				}
				else {
					int startindex = 0;
				
					for (int i = 0; i < input.length(); i++) {
						if (input.charAt(i) == (' ')) {
							keptdice.add(Integer.parseInt(input.substring(startindex, i)));
							startindex = i + 1;
						}
					}
					
					for (int i = 1; i <= 5; i++) {
						rolleddice.add(i);
					}
					keptdice.add(Integer.parseInt(input.substring(startindex)));
					
					for (int i = 0; i < keptdice.size(); i++) {
						if (rolleddice.contains(keptdice.get(i))) {
							rolleddice.remove(keptdice.get(i));
						}
					}
					
					for (int i = 0; i < rolleddice.size(); i++) {
						yahtzee.roll(rolleddice.get(i));
					}
				}
				System.out.println(yahtzee.showDice());
				keptdice.clear();
				rolleddice.clear();
			}
			System.out.println("Final dice: " + Arrays.toString(yahtzee.getDice()));
			YahtzeeScore score = new YahtzeeScore(yahtzee.getDice());
			System.out.println("Score:\n");
			if (ones2 == false) {
				System.out.println("1s*: " + score.getUpperScore(1));
			}
			else {
				System.out.println("1s: " + ones);
			}
			if (twos2 == false) {
				System.out.println("2s*: " + score.getUpperScore(2));
			}
			else {
				System.out.println("2s: " + twos);
			}
			if (threes2 == false) {
				System.out.println("3s*: " + score.getUpperScore(3));
			}
			else {
				System.out.println("3s: " + threes);
			}
			if (fours2 == false) {
				System.out.println("4s*: " + score.getUpperScore(4));
			}
			else {
				System.out.println("4s: " + fours);
			}
			if (fives2 == false) {
				System.out.println("5s*: " + score.getUpperScore(5));
			}
			else {
				System.out.println("5s: " + fives);
			}
			if (sixes2 == false) {
				System.out.println("6s*: " + score.getUpperScore(6));
			}
			else {
				System.out.println("6s: " + sixes);
			}
			if (threeofakind2 == false) {
				System.out.println("Three of a kind*: " + score.scoreThreeOfAKind());
			}
			else {
				System.out.println("Three of a kind: " + threeofakind);
			}
			if (fourofakind2 == false) {
				System.out.println("Four of a kind*: " + score.scoreFourOfAKind());
			}
			else {
				System.out.println("Four of a kind: " + fourofakind);
			}
			if (fullhouse2 == false) {
				System.out.println("Full House*: " + score.scoreFullHouse());
			}
			else {
				System.out.println("Full House: " + fullhouse);
			}
			if (smallstraight2 == false) {
				System.out.println("Small straight*: " + score.scoreSmallStraight());
			}
			else {
				System.out.println("Small straight: " + smallstraight);
			}
			if (largestraight2 == false) {
				System.out.println("Large straight*: " + score.scoreLargeStraight());
			}
			else {
				System.out.println("Large straight: " + largestraight);
			}
			if (chance2 == false) {
				System.out.println("Chance*: " + score.scoreChance());
			}
			else {
				System.out.println("Chance: " + chance);
			}
			if (yahtzee3 == false) {
				System.out.println("Yahtzee*: " + score.scoreYahtzee());
			}
			else {
				System.out.println("Yahtzee: " + yahtzee2);
			}
			
			while (true) {
				System.out.print("Enter the option you would like to choose: ");
				String yaht = s.nextLine();
				
				if (yaht.equals("1s") && ones2 == false) {
					ones = score.getUpperScore(1);
					ones2 = true;
					break;
				}
				else if (yaht.equals("2s") && twos2 == false) {
					twos = score.getUpperScore(2);
					twos2 = true;
					break;
				}
				else if (yaht.equals("3s") && threes2 == false) {
					threes = score.getUpperScore(3);
					threes2 = true;
					break;
				}
				else if (yaht.equals("4s") && fours2 == false) {
					fours = score.getUpperScore(4);
					fours2 = true;
					break;
				}
				else if (yaht.equals("5s") && fives2 == false) {
					fives = score.getUpperScore(5);
					fives2 = true;
					break;
				}
				else if (yaht.equals("6s") && sixes2 == false) {
					sixes = score.getUpperScore(6);
					sixes2 = true;
					break;
				}
				else if (yaht.equals("three of a kind") && threeofakind2 == false) {
					threeofakind = score.scoreThreeOfAKind();
					threeofakind2 = true;
					break;
				}
				else if (yaht.equals("four of a kind") && fourofakind2 == false) {
					fourofakind = score.scoreFourOfAKind();
					fourofakind2 = true;
					break;
				}
				else if (yaht.equals("full house") && fullhouse2 == false) {
					fullhouse = score.scoreFullHouse();
					fullhouse2 = true;
					break;
				}
				else if (yaht.equals("small straight") && smallstraight2 == false) {
					smallstraight = score.scoreSmallStraight();
					smallstraight2 = true;
					break;
				}
				else if (yaht.equals("large straight") && largestraight2 == false) {
					largestraight = score.scoreLargeStraight();
					largestraight2 = true;
					break;
				}
				else if (yaht.equals("chance") && chance2 == false) {
					chance = score.scoreChance();
					chance2 = true;
					break;
				}
				else if (yaht.equals("yahtzee") && yahtzee3 == false) {
					yahtzee2 = score.scoreYahtzee();
					yahtzee3 = true;
					break;
				}
				else {
					System.out.println("Enter a valid option");
				}
				if (score.scoreYahtzee() == 50 && yahtzee3 == true) {
					yahtzee2 += score.scoreBonusYahtzee();
				}
			}
		}
		System.out.println("\nFINAL SCORE: \n");
		System.out.println("-------------------");
		System.out.println("1s: " + ones);
		System.out.println("2s: " + twos);
		System.out.println("3s: " + threes);
		System.out.println("4s: " + fours);
		System.out.println("5s: " + fives);
		System.out.println("6s: " + sixes);
		int sum = ones + twos + threes + fours+ fives + sixes;
		System.out.println("Sum: " + sum);
		int bonus = 0;
		if (sum > 63) {
			bonus = 35;
		}
		System.out.println("Bonus: " + bonus);
		System.out.println("-------------------");
		System.out.println("Three of a kind: " + threeofakind);
		System.out.println("Four of a kind: " + fourofakind);
		System.out.println("Full House: " + fullhouse);
		System.out.println("Small straight: " + smallstraight);
		System.out.println("Large straight: " + largestraight);
		System.out.println("Chance: " + chance);
		System.out.println("Yahtzee: " + yahtzee2);
		int total = sum + bonus + threeofakind + fourofakind + fullhouse + smallstraight + largestraight + chance
				 + yahtzee2;
		System.out.println("TOTAL SCORE: " + total);
	}	
}

