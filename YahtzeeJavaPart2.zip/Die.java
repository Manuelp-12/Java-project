package die;

/* Starter file for JHU CTY AP CS Course Final Project 
 * Initial code for Die with stub implementations
 */

public class Die {
	private int value;
	
	public Die() {
		roll();
		value = getValue();
	}
	
	/* Roll a die and return its numerical value */
    public int roll() {
    	value = (int)((Math.random() * 6) + 1);
    	return value;
    }
    
    /* Return numerical value of the die without re-rolling it */
    public int getValue() {
    	return value;
    }
}
